function scroll_to_class(chosen_class) {
    var nav_height = $('nav').outerHeight();
    var scroll_to = $(chosen_class).offset().top - nav_height;

    if ($(window).scrollTop() != scroll_to) {
        $('html, body').stop().animate({scrollTop: scroll_to}, 1000);
    }
}


jQuery(document).ready(function () {

    var background_url = null;
    var gform_url = null;


    if(window.location.href.search('test.codespace') != -1){
        document.title = "CodeSpace Challenge";
        background_url = "assets/img/backgrounds/codespace.jpg";
        gform_url = "https://script.google.com/a/brightroom.co.za/macros/s/AKfycbwdez7IjI0lJ3DZf087oM2haNrqCK3kxNgpxmh8acDVkUvbzNg/exec";
        $('#facilitator-message').hide();
    }
    else if(window.location.href.search('challenge.code4ct') != -1){
        background_url = "assets/img/backgrounds/code4ct.jpg";
        gform_url = "https://script.google.com/macros/s/AKfycbw8lqGsGdvn-AidPEbxYGmL4fOPCpCS3gXlWuNwycrYR2z_cK4/exec";
        $('.description-text p').html("Please complete the following exercise as part of your application to Code4CT's Grade 11 program.");
    }
    else if(window.location.href.search('code4ct') != -1){
        background_url = "assets/img/backgrounds/code4ct.jpg";
        gform_url = "https://script.google.com/macros/s/AKfycbwhSF1Be8Fu8f4wyrYzLBFvTnCWfBOZx4qmoHfWJNLsI2PxrIk/exec?code4ct";
    //}else if(window.location.href.search('aptitude-test') != -1){
    }else if(window.location.href.search('dff-challenge') != -1){
        background_url = "assets/img/backgrounds/code4ct.jpg";
        gform_url = "https://script.google.com/macros/s/AKfycbxBWuk3Q-s0gA1HGCrzEuQcVTSRxmW_bb3u__HjjTaheAm7pdQ/exec";
        //DFF
    }else if(window.location.href.search('lifechoices-challenge') != -1){
        background_url = "assets/img/backgrounds/code4ct.jpg";
        gform_url = "https://script.google.com/macros/s/AKfycbz7SiyMUg4NX2FUkEF5SwoVNqwCy_lBFpNPqSPIDbOKpxBWkfc/exec?lifechoices";
        //DFF
    }
    else{
        document.title = "CodeSpace Challenge";
        background_url = "assets/img/backgrounds/code4ct.jpg";
        gform_url = "https://script.google.com/a/brightroom.co.za/macros/s/AKfycbwdez7IjI0lJ3DZf087oM2haNrqCK3kxNgpxmh8acDVkUvbzNg/exec";
        $('#facilitator-message').hide();

    }


    console.log(gform_url);

    document.getElementById('gform').action = gform_url;

    /*
     Fullscreen background
     */
    $.backstretch(background_url);

    /*
     Multi Step Form
     */
    $('.msf-form form fieldset:first-child').fadeIn('slow');

    //// next step
    //$('.msf-form form .btn-next').on('click', function() {
    //	$(this).parents('fieldset').fadeOut(400, function() {
    //    	$(this).next().fadeIn();
    //		scroll_to_class('.msf-form');
    //    });
    //});
    //
    //// previous step
    $('.msf-form form .btn-previous').on('click', function () {
        $(this).parents('fieldset').fadeOut(400, function () {
            $(this).prev().fadeIn();
            scroll_to_class('.msf-form');
        });
    });


    //$("input:radio[name='html_radio']").is(":checked");


    $(".msf-form form .btn-next").on('click', function () {

        jQuery.validator.setDefaults({
            debug: true,
            success: "valid"
        });

        var form = $("#gform");
        var button = $(this);
        form.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            highlight: function (element, errorClass, validClass) {
                $(element).closest('.form-group').addClass("has-error");
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).closest('.form-group').removeClass("has-error");
            },
            rules: {
                'first-name': {
                    required: true,
                    minlength: 3
                },
                'last-name': {
                    required: true,
                    minlength: 3
                },
                school: {
                    required: true
                },
                gender: {
                    required: true
                },
                location: {
                    required: true
                },
                age: {
                    required: true
                },
                email: {
                    'email': true,
                    required: function(element){
                        return $("#mobile").val().length == 0;
                    }
                },
                mobile: {
                    required: function(element){
                        return $("#email").val().length == 0;
                    }
                },
                maths_mark: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes';
                    }
                },
                english_mark: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes';
                    }
                }, ethnicity: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes';
                    }
                },sa_citizen: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes';
                    }
                },work_visa: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes' && $("#sa_citizen").val() == 'No';
                    }
                },full_time_work: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes';
                    }
                },why: {
                    required: function(element) {
                        return $("#financial_assistance").val() == 'Yes';
                    }
                }
            },
            messages: {
                'first-name': {
                    required: "Name required"
                },
                'last-name': {
                    required: "Last name required"
                },
                email: {
                    required: "Email required"
                },
                mobile: {
                    required: "Mobile required"
                },
                school: {
                    required: "School required"
                }
            }
        });
        if (form.valid() === true) {
            $(this).parents('fieldset').fadeOut(400, function () {
                $(this).next().fadeIn();
                scroll_to_class('.msf-form');
                if (button.hasClass('timer-start')) {
                    var thirtyMinutesLater = new Date();
                    thirtyMinutesLater.setMinutes(thirtyMinutesLater.getMinutes() + 30);
                    $("#clock")
                        .countdown(thirtyMinutesLater, function (event) {
                            $(this).text(
                                event.strftime('Time remaining: %M:%S')
                            )
                        })
                        .on('finish.countdown', function (event) {
                            $(this).html('Time up!').parent().addClass('disabled');

                            $("#submit-button").trigger("click");
                            $('#thank-you-message').text('You ran out of time but your results have been saved. Well done on getting that far!')

                        });


                }
            });
        }


    });


        $('a.results-link') .click(function(e) {
            e.preventDefault();
            var count = $(this).attr('data-clicked');
            count = parseInt(count) + 1;
            $(this).attr('data-clicked', count);

            if(count == 3){
                $('.results-text').show();
            }
        });



    $('#financial_assistance').on('change',function(){
       var o = this.value;

        if(o == 'Yes'){
            $('.fa-field').show();
        }
        if(o == 'No'){
            $('.fa-field').hide();
        }
    });

    $('#sa_citizen').on('change',function(){
       var o = this.value;

        if(o == 'No'){
            $('.work-visa').show();
        }
        if(o == 'Yes'){
            $('.work-visa').hide();
        }
    });


});
