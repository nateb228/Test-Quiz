<?php

$answers = array(
    'question-1' => array(
        'a'=>'2',
        'category' => 'attention to detail'
    ),
    'question-2' => array(
        'a'=>'6',
        'category' => 'logical reasoning'
    ),
    'question-3' => array(
        'a'=>'40',
        'category' => 'logical reasoning'
    ),
    'question-4' => array(
        'a'=>'7',
        'category' => 'complex procedures'
    ),
    'question-5' => array(
        'a'=>'H',
        'category' => 'complex procedures'
    ),
    'question-6' => array(
        'a'=>'5',
        'category' => 'attention to detail'
    ),
    'question-7' => array(
        'a'=>'B',
        'category' => 'pattern recognition'
    ),
    'question-8' => array(
        'a'=>'D',
        'category' => 'pattern recognition'
    ),
    'question-9' => array(
        'a'=>'D',
        'category' => 'pattern recognition'
    ),
    'question-10' => array(
        'a'=>'E',
        'category' => 'pattern recognition'
    ),
    'question-11' => array(
        'a'=>'D',
        'category' => 'pattern recognition'
    ),
    'question-12' => array(
        'a'=>'26',
        'category' => 'complex procedures'
    ),
    'question-13' => array(
        'a'=>'102',
        'category' => 'complex procedures'
    ),
    'question-14' => array(
        'a'=>'48',
        'category' => 'complex procedures'
    ),
    'question-15' => array(
        'a'=>'83',
        'category' => 'complex procedures'
    ),
    'question-16' => array(
        'a'=>'G',
        'category' => 'logical reasoning'
    ),
    'question-17' => array(
        'a'=>'Y',
        'category' => 'logical reasoning'
    ),
    'question-18' => array(
        'a'=>'J',
        'category' => 'logical reasoning'
    ),
    'question-19' => array(
        'a'=>'P',
        'category' => 'logical reasoning'
    ),
    'question-20' => array(
        'a'=>'6',
        'category' => 'attention to detail'
    ),
);

echo json_encode($answers);